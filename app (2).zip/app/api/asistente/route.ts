import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const mensaje = formData.get('mensaje') as string;
    const file = formData.get('file') as File | null;

    const [{ data: lotes }, { data: proveedores }, { data: insumos }, { data: actividades }] = await Promise.all([
      supabase.from('lotes').select('id, nombre'),
      supabase.from('proveedores').select('id, razon_social, cuit').eq('activo', true),
      supabase.from('insumos').select('id, nombre, unidad, categoria'),
      supabase.from('actividades').select('id, nombre'),
    ]);

    const contexto = `Sos un asistente para un sistema de gestión agropecuaria argentino.
Tenés acceso a los siguientes datos del sistema:

LOTES: ${JSON.stringify(lotes?.map(l => ({ id: l.id, nombre: l.nombre })))}
PROVEEDORES: ${JSON.stringify(proveedores?.map(p => ({ id: p.id, nombre: p.razon_social, cuit: p.cuit })))}
INSUMOS: ${JSON.stringify(insumos?.map(i => ({ id: i.id, nombre: i.nombre, unidad: i.unidad, categoria: i.categoria })))}
ACTIVIDADES: ${JSON.stringify(actividades?.map(a => ({ id: a.id, nombre: a.nombre })))}

Tu tarea es interpretar el mensaje del usuario y responder SOLO con un JSON con esta estructura:
{
  "accion": "cargar_factura" | "cargar_labor" | "cargar_remito" | "crear_insumo" | "consulta",
  "mensaje_usuario": "respuesta amigable explicando qué vas a hacer",
  "insumos_sin_match": ["nombre del insumo que no encontré en la lista"],
  "datos": {
    // Para cargar_factura:
    // proveedor_id: uuid del proveedor más cercano de la lista
    // fecha: YYYY-MM-DD
    // fecha_vencimiento: YYYY-MM-DD o null
    // tipo_comprobante: "Factura A" / "Factura B" / "Factura C" / "Nota de Crédito A" / etc
    // numero_factura: formato 0000-00000000
    // concepto: descripción breve
    // tipo: "Insumos" / "Servicios" / "Combustible" / "Otros" según el concepto
    // moneda: "ARS" o "USD"
    // dolar: tipo de cambio si es USD, sino null
    // monto_neto: neto gravado EN PESOS ARGENTINOS (si es USD multiplicar por tipo de cambio)
    // alicuota_iva: 10.5 / 21 / 27 / 0
    // monto_iva: IVA EN PESOS ARGENTINOS
    // percepciones: EN PESOS ARGENTINOS
    // retenciones: 0
    // no_gravado: EN PESOS ARGENTINOS
    // cae: número de CAE sin espacios
    // items: array de objetos con { descripcion, insumo_id (uuid si encontraste match o null), cantidad, unidad, precio_unitario, descuento, precio_neto, total } — todos los importes en ARS

    // Para cargar_labor:
    // Tipo: "Fumigación" / "Siembra" / "Cosecha" / "Fertilización" / "Labranza"
    // Fecha: YYYY-MM-DD
    // Lote_id: uuid del lote más cercano
    // hectareas: número
    // Costo_total: en ARS

    // Para cargar_remito:
    // proveedor_id, fecha, numero_remito, observaciones

    // Para crear_insumo:
    // nombre, categoria, unidad, subcategoria

    // Para consulta: null
  }
}

IMPORTANTE:
- Todos los importes deben estar en ARS (pesos argentinos).
- Si la factura está en USD, multiplicá cada importe por el tipo de cambio para convertir a ARS.
- El campo monto_neto siempre en ARS.
- Mapeá el proveedor al id más similar de la lista PROVEEDORES usando el CUIT o nombre.
- Para cada ítem de la factura, intentá matchear con un insumo de la lista INSUMOS por nombre similar. Si encontrás match, incluí el insumo_id. Si no encontrás match, dejá insumo_id: null y agregá el nombre a "insumos_sin_match".
- Respondé SOLO con JSON válido, sin texto extra ni backticks.`;

    let content: any[];

    if (file) {
      const bytes = await file.arrayBuffer();
      const base64 = Buffer.from(bytes).toString('base64');
      const isPdf = file.type === 'application/pdf';
      content = [
        {
          type: isPdf ? 'document' : 'image',
          source: { type: 'base64', media_type: file.type, data: base64 }
        },
        { type: 'text', text: contexto + '\n\nAnalizá este archivo y extraé los datos relevantes.' }
      ];
    } else {
      content = [{ type: 'text', text: contexto + '\n\nMensaje del usuario: ' + mensaje }];
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY!,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 2096,
        messages: [{ role: 'user', content }]
      })
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '';
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);
    return NextResponse.json(parsed);

  } catch (error: any) {
    console.error('Error asistente:', error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}